const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const multer = require('multer');
const nodemailer = require('nodemailer');
const session = require('express-session');
const Slot = require("./models/slot");

const app = express();
const PORT = process.env.PORT || 7001;

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/myapp', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Define User Schema
const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String,
  profilePic: String,
  resetToken: String,
  resetTokenExpiresAt: Date,
  uid: {
    type: String,
    unique: true
  }
});

const User = mongoose.model('User', userSchema);

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use(session({
  secret: 'your_secret_key',
  resave: false,
  saveUninitialized: true
}));

// Set up multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, './uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  }
});

const upload = multer({ storage: storage });

// Create a nodemailer transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'your-email@gmail.com',
    pass: 'your-email-password'
  }
});

// Routes
app.get('/', (req, res) => {
  res.render('index', { user: req.session.user });
});

app.get('/login', (req, res) => {
  res.render('login');
});
app.get('/payment', (req, res) => {
  res.render('payment');
});

app.get('/signup', (req, res) => {
  res.render('signup');
});

// Handle signup form submission
app.post('/signup', upload.single('profilePic'), async (req, res) => {
  try {
    const { name, email, password, confirmPassword, uid } = req.body;
    const profilePic = req.file ? req.file.filename : '';

    if (password !== confirmPassword) {
      return res.status(400).send('Passwords do not match');
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      name,
      email,
      profilePic,
      password: hashedPassword,
      uid // Save UID to user document
    });

    await newUser.save();

    res.status(201).send('User registered successfully');
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal server error');
  }
});

// Route to render the slot booking page
app.get('/book-slot', isAuthenticated, (req, res) => {
  res.render('book-slot');
});

// Route to handle slot booking form submission
// Route to handle slot booking form submission
app.post('/book-slot', isAuthenticated, async (req, res) => {
  try {
    // Check if the user already has a booked slot
    const existingBooking = await Slot.findOne({ userId: req.session.user.uid });
    
    if (existingBooking) {
      if (existingBooking) {
        // If the user already has a booked slot, show a popup and redirect to booking success page
        return res.render('booking-success', { bookedSlot: existingBooking });
      }
    }

    // Proceed with slot booking
    const { location, vehicleType, slot, startTime, endTime } = req.body;

    const bookedSlot = new Slot({
      location,
      vehicleType,
      slot,
      startTime,
      endTime,
      userId: req.session.user.uid
    });

    await bookedSlot.save();

    res.redirect('/booking-success');
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal server error');
  }
});

// Route to handle slot checkout
// Route to handle slot checkout
app.post('/checkout', isAuthenticated, async (req, res) => {
  try {
    // Find the booked slot for the user
    const bookedSlot = await Slot.findOne({ userId: req.session.user.uid });

    if (!bookedSlot) {
      return res.status(404).send('No booked slot found for the user');
    }

    // Remove the booked slot from the database
    await Slot.deleteOne({ userId: req.session.user.uid });

    // Send a message indicating that the slot has been freed
    res.status(200).send('Slot freed successfully');

    // Redirect to the home page after a short delay
    setTimeout(() => {
      res.redirect('/index');
    }, 100); // Redirect after 3 seconds (adjust the delay as needed)
  } catch (error) {
    console.error(error);
    
  }
});



// Route to render the booking success page
app.get('/booking-success', isAuthenticated, async (req, res) => {
  try {
    // Find the booked slot for the user
    const bookedSlot = await Slot.findOne({ userId: req.session.user.uid });

    if (!bookedSlot) {
      return res.status(404).send('No booked slot found for the user');
    }

    res.render('booking-success', { bookedSlot }); // Pass bookedSlot data to the template
  } catch (error) {
    console.error('Error fetching booked slot:', error);
    res.status(500).send('Internal server error');
  }
});

// Handle login form submission
app.post('/login', async (req, res) => {
  try {
    const { uid, password } = req.body;

    const user = await User.findOne({ uid });

    if (!user) {
      return res.status(400).render('login', { error: 'Invalid UID or password' });
    }

    const passwordMatch = await bcrypt.compare(password, user.password);

    if (passwordMatch) {
      req.session.user = {
        name: user.name,
        email: user.email,
        profilePic: user.profilePic,
        uid: user.uid
      };
      return res.redirect('/');
    } else {
      return res.status(400).render('login', { error: 'Invalid UID or password' });
    }
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).render('login', { error: 'Internal server error' });
  }
});

// Handle forgot password form submission
app.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;

    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).send('User not found');
    }

    const token = generateUniqueToken();

    user.resetToken = token;
    user.resetTokenExpiresAt = Date.now() + 3600000;

    await user.save();

    await transporter.sendMail({
      from: 'your-email@gmail.com',
      to: user.email,
      subject: 'Password Reset',
      text: `Dear ${user.name},\n\nYou have requested to reset your password. Please use the following token to reset your password: ${token}\n\nIf you did not request this, please ignore this email.\n\nBest regards,\nYour App`
    });

    res.redirect('/reset-password');
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal server error');
  }
});

// Render reset password page
app.get('/reset-password', (req, res) => {
  res.render('reset-password');
});

// Handle reset password form submission
app.post('/reset-password', async (req, res) => {
  try {
    const { email, token, newPassword } = req.body;

    const user = await User.findOne({ email, resetToken: token, resetTokenExpiresAt: { $gt: Date.now() } });

    if (!user) {
      return res.status(404).send('Invalid or expired token');
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    user.resetToken = undefined;
    user.resetTokenExpiresAt = undefined;

    await user.save();

    res.redirect('/login?reset=success');
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal server error');
  }
});

// Route to render the user's profile page
app.get('/profile', isAuthenticated, async (req, res) => {
  try {
    const { uid } = req.session.user;

    const user = await User.findOne({ uid });

    if (!user) {
      return res.status(404).send('User not found');
    }

    res.render('profile', {
      name: user.name,
      email: user.email,
      profilePic: user.profilePic,
      uid: user.uid
    });
  } catch (error) {
    console.error('Error finding user by UID:', error);
    res.status(500).send('Internal server error');
  }
});

// Handle logout
app.get('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.error('Error destroying session:', err);
      res.status(500).send('Internal server error');
    } else {
      res.redirect('/login');
    }
  });
});

// Render forgot password page
app.get('/forgot-password', (req, res) => {
  res.render('forgot-password');
});

// Route to handle slot checkout
// Route to handle slot checkout
app.post('/checkout', isAuthenticated, async (req, res) => {
  try {
    // Find the booked slot for the user
    const bookedSlot = await Slot.findOne({ userId: req.session.user.uid });

    if (!bookedSlot) {
      return res.status(404).send('No booked slot found for the user');
    }

    // Remove the booked slot from the database
    await Slot.deleteOne({ userId: req.session.user.uid });

    // Send a message indicating that the slot has been freed
    console.log("slot freed");

    
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal server error');
  }
});


// Define the isAuthenticated middleware
function isAuthenticated(req, res, next) {
  if (req.session.user) {
    return next();
  } else {
    res.redirect('/login');
  }
}

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
// Route to render the slot freed page
app.get('/slot-freed', isAuthenticated, (req, res) => {
  res.render('slot-freed');
});
// Route to handle slot freed
app.get('/slot-freed', isAuthenticated, (req, res) => {
  res.redirect('/'); // Redirect to the home page or any other appropriate page
});


// Function to generate a unique token
function generateUniqueToken() {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}
