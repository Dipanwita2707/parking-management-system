const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.json());

const availableSlots = {
  // Sample data for available parking slots
  admission: {
    car: 10,
    bike: 20,
    cycle: 15,
    'e-rikshaw': 5,
    bus: 2,
    ambulance: 3
  },
  '56': {
    car: 8,
    bike: 15,
    cycle: 12,
    'e-rikshaw': 4,
    bus: 1,
    ambulance: 2
  },
  '13': {
    car: 12,
    bike: 25,
    cycle: 20,
    'e-rikshaw': 6,
    bus: 3,
    ambulance: 4
  },
  hospital: {
    car: 15,
    bike: 30,
    cycle: 25,
    'e-rikshaw': 8,
    bus: 4,
    ambulance: 5
  },
  playground: {
    car: 5,
    bike: 10,
    cycle: 8,
    'e-rikshaw': 3,
    bus: 1,
    ambulance: 2
  }
};

app.post('/book-slot', (req, res) => {
  const { location, vehicleType } = req.body;

  if (!location || !vehicleType) {
    return res.status(400).json({ error: 'Location and vehicle type are required.' });
  }

  if (!availableSlots.hasOwnProperty(location)) {
    return res.status(400).json({ error: 'Invalid location.' });
  }

  if (!availableSlots[location].hasOwnProperty(vehicleType)) {
    return res.status(400).json({ error: 'Invalid vehicle type for the specified location.' });
  }

  const slotsAvailable = availableSlots[location][vehicleType];
  if (slotsAvailable > 0) {
    availableSlots[location][vehicleType]--;
    return res.status(200).json({ message: 'Slot booked successfully.' });
  } else {
    return res.status(400).json({ error: 'No available slots for the specified vehicle type at the specified location.' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
