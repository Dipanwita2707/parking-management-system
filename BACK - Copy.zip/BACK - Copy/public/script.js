function toggleMenu() {
    const menu = document.querySelector('.menu');
    menu.classList.toggle('active');
}
function toggleMenu() {
    const menu = document.querySelector('.menu');
    menu.classList.toggle('active');
    
    // Apply specific styling for Windows when the menu is active
    if (isWindows() && menu.classList.contains('active')) {
        menu.classList.add('windows');
    } else {
        menu.classList.remove('windows');
    }
}
