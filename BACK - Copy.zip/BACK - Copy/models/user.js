// user.js

const mongoose = require('mongoose');

// Define User Schema
const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true // Ensure email field is unique
  },
  uid: {
    type: String,
    required: true,
    unique: true // Ensure uid field is unique
  },
  profilePic: {
    data: Buffer,
    contentType: String
  },
  password: {
    type: String,
    required: true
  }
});

const User = mongoose.model('User', userSchema);

module.exports = User;
