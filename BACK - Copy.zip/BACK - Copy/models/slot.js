const mongoose = require('mongoose');

// Define the Slot schema
const slotSchema = new mongoose.Schema({
    location: String,
  vehicleType: String,
  slot: String,
  startTime: String,
  endTime: String,
  userId: String // Define userId as String, not ObjectId
});

// Create the Slot model
const Slot = mongoose.model('Slot', slotSchema);

module.exports = Slot;
