const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String,
    profilePic: String,
    resetToken: String,
    resetTokenExpiresAt: Date,
    uid: {
      type: String,
      unique: true
    },
    activeBooking: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Slot' // Reference to the Slot model
    }
  });
  